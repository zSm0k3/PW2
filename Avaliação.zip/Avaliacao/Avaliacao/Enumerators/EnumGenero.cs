﻿namespace Avaliacao.Enumerators
{
    public enum EnumGenero
    {
        Ação = 1,
        Suspense =  2,
        Terror = 3,
        Comédia = 4,
        Drama = 5
    }
}
