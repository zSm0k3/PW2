﻿using Avaliacao.Domain;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Avaliacao.Configurations
{
    public class FilmeConfiguration : IEntityTypeConfiguration<Filme>
    {
        public void Configure(EntityTypeBuilder<Filme> builder)
        {
           builder.HasKey(x => x.Id);

            builder.Property(x => x.Titulo)
                 .IsRequired()
                 .HasMaxLength(100);

            builder.Property(p => p.Genero)
                .IsRequired();

            builder.Property(x => x.Diretor)
                 .IsRequired(false)
                 .HasMaxLength(50);

            builder.Property(p => p.AnoLancamento)
               .IsRequired();

            builder.Property(x => x.Sinopse)
                 .IsRequired(false)
                 .HasMaxLength(300);

            builder.Property(p => p.Duracao)
               .IsRequired();

            builder.ToTable("TAB_Filme");
        }
    }
}
