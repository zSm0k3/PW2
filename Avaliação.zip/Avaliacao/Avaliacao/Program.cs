using Avaliacao.Context;
using Avaliacao.Domain;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
builder.Services.AddDbContext<AcervoContext>();

var app = builder.Build();

app.UseSwagger();
app.UseSwaggerUI();
app.UseHttpsRedirection();

app.MapPost("/filme/adicionar", (AcervoContext context, Filme filme) =>
{
    context.FilmeSet.Add(filme);
    context.SaveChanges();

    return Results.Created("created", "Filme adicionado com sucesso.");
})

.WithOpenApi(info =>
{
    info.Description = "Endpoint é utilizado para cadastrar um filmes";
    info.Summary = "Adicionar Filme";
    return info;
})
.WithTags("Filmes");

app.MapGet("/filme/listar", (AcervoContext context) =>
{
    var cursos = context.FilmeSet.ToList();
    return Results.Ok(cursos.OrderBy(c => c.Id));
})
.WithOpenApi(info =>
{
    info.Description = "Endpoint é utilizado para listar todos os filmes";
    info.Summary = "Listar Filmes";
    return info;
})
.WithTags("Filmes");

app.MapPut("/filme/atualizar", (AcervoContext context, Filme filme) =>
{
    context.FilmeSet.Update(filme);
    context.SaveChanges();

    return Results.Ok("Filme atualizado com sucesso.");
})
.WithOpenApi(info =>
{
    info.Description = "Endpoint é utilizado para atualizar filmes";
    info.Summary = "Atualizar Filmes";
    return info;
})
.WithTags("Filmes");

app.MapDelete("/filme/remover/{id:int}", (AcervoContext context, int id) =>
{
    var filme = context.FilmeSet.Find(id);
    context.FilmeSet.Remove(filme);
    context.SaveChanges();

    return Results.Ok("Filme removido com sucesso.");
})
.WithOpenApi(info =>
{
    info.Description = "Endpoint é utilizado para remover filmes";
    info.Summary = "Remover Filmes";
    return info;
})
.WithTags("Filmes");

app.Run();