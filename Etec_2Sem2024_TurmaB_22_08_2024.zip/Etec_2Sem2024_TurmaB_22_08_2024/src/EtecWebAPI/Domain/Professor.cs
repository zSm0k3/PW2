﻿namespace EtecWebAPI.Domain
{
    public class Professor
    {
        public int Id { get; set; }
        public string Nome { get; set; } = string.Empty;
    }
}
