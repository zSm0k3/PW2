﻿namespace EtecWebAPI.Enumerators
{
    public enum EnumPeriodo
    {
        Manha = 1,
        Tarde = 2,
        Noite = 3
    }
}
