﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace EtecWebAPI.Migrations
{
    /// <inheritdoc />
    public partial class Adicionado_Campo_Apelido_Tabela_Curso : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "Apelido",
                table: "TB_Curso",
                type: "varchar(10)",
                maxLength: 10,
                nullable: true)
                .Annotation("MySql:CharSet", "utf8mb4");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Apelido",
                table: "TB_Curso");
        }
    }
}
